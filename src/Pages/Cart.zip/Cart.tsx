import React, { useEffect, useState } from "react";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import { generateToken } from "../Utils/jwtUtils";
import { authorizedFetch } from "../Utils/authorizedFetch";

// Type definitions for API data
type Category = {
  id: number;
  name: string;
  service_id: number;
  priority: number;
  image: string | null;
};

type Service = {
  id: number;
  name: string;
  status: number;
  coming_soon: number;
  priority: number;
  image_url: string;
};

type Slot = {
  slot_id: number;
  start_time: string;
  end_time: string;
};

type SlotDay = {
  date: string;
  weekday: string;
  day: string;
  slots: Slot[];
};

const Cart: React.FC = () => {
  const { cart, removeFromCart, clearCart, addToCart } = useCart();
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [pickupSlots, setPickupSlots] = useState<Record<string, SlotDay>>({});

  // Map service IDs to service names
  const serviceNames: Record<number, string> = {
    1: "Steam Iron",
    2: "Wash & Iron",
    3: "Dry Cleaning",
    6: "Wash & Fold"
  };

  // Fetch categories and services data
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Generate a temporary token for API access
        const tempToken = await generateToken({
          version_name: "1.0.0",
          version_code: "1",
          device_id: "web-" + Date.now(),
          device_type: "web",
          device_model: navigator.userAgent.substring(0, 50)
        });

        // Fetch all services
        const servicesResponse = await authorizedFetch("https://api-dev.ironbhai.com/v1/app/services", {
          headers: {
            "Authorization": `Bearer ${tempToken}`,
          },
        });

        const servicesData = await servicesResponse.json();
        if (servicesResponse.ok && servicesData.ok) {
          setServices(servicesData.data);
        }

        // For each service in the cart, fetch its categories
        // const serviceIds = [...new Set(cart.map(item => item.category_id))];
        const allCategories: Category[] = [];

        // We need to fetch categories for each service
        // This is a simplified approach - in a real app, you might want to optimize this
        for (const serviceId of [1, 2, 3, 6]) {
          try {
            const response = await authorizedFetch(`https://api-dev.ironbhai.com/v1/app/services/${serviceId}`, {
              headers: {
                "Authorization": `Bearer ${tempToken}`,
              },
            });

            const data = await response.json();
            if (response.ok && data.ok && data.data.categories) {
              allCategories.push(...data.data.categories);
            }
          } catch (err) {
            console.error(`Error fetching categories for service ${serviceId}:`, err);
          }
        }

        setCategories(allCategories);
      } catch (err) {
        console.error("Fetch error:", err);
      } finally {
        setLoading(false);
      }
    };

     const fetchPickupSlots = async () => {
      try {
        const tempToken = await generateToken({
          version_name: "1.0.0",
          version_code: "1",
          device_id: "web-" + Date.now(),
          device_type: "web",
          device_model: navigator.userAgent.substring(0, 50)
        });

        const slotsResponse = await authorizedFetch(
          "https://api-dev.ironbhai.com/v1/app/orders/pickup-available-slots",
          {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${tempToken}`,
              "Content-Type": "application/json",
              "authToken": "U2FsdGVkX18QUgxbBC7FGmxnYaSe1MN6QFMeb7Urz0BmBM7q8a0GYwAGFwq7daws6o4048gm5dwp0KxaMqYGcL3+JZCZI8QBlKNhg6e+yNYJT6ox8fza1lIEO1pRdR8EXDqvsjG3y8k0PZ1bWE6WmxdrLN5ZMxy3JXBcq43ITWyZ3x65Udn+GFkKfUoUGsu0+95rT/6YgDmrhtMrQN9MWF1MJzLcu6rEjuk5wr9keQxlaXqRUof+JH4U+UdHdl3/E7FvbNHWZFTYp+R+Xg8LcPZHgMqW9/MMO+kus1sWnxI=",
            },
            body: JSON.stringify({ token: "Asia/Kolkata" }),
          }
        );

        const slotsData = await slotsResponse.json();
        if (slotsResponse.ok && slotsData.ok) {
          setPickupSlots(slotsData.data);
        }
      } catch (err) {
        console.error("Error fetching pickup slots:", err);
      }
    };

    if (cart.length > 0) {
      fetchData();
      fetchPickupSlots();
    } else {
      setLoading(false);
    }

  }, [cart]);

  // Get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : `Category ${categoryId}`;
  };

  // Get service name by category ID
  const getServiceName = (categoryId: number) => {
    const category = categories.find(cat => cat.id === categoryId);
    if (category) {
      const serviceId = category.service_id;
      const service = services.find(svc => svc.id === serviceId);
      return service ? service.name : serviceNames[serviceId] || `Service ${serviceId}`;
    }
    return "Unknown Service";
  };

  // Calculate total for all items
  const total = cart.reduce((sum, item) => sum + Number(item.sale) * item.quantity, 0);

  // Function to increase quantity
  const increaseQuantity = (item: any) => {
    addToCart({
      id: item.id,
      name: item.name,
      mrp: item.mrp,
      sale: item.sale,
      category_id: item.category_id,
    });
  };

  // Function to decrease quantity
  const decreaseQuantity = (id: number) => {
    removeFromCart(id);
  };

  const handleContinueShopping = () => {
    navigate("/services");
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-4 sm:p-6">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">Your Cart</h1>
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <p className="text-gray-600">Loading cart details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">Your Cart</h1>

      {cart.length === 0 ? (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <div className="mx-auto w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">Looks like you haven't added any items to your cart yet</p>
          <button
            onClick={handleContinueShopping}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300 ease-in-out transform hover:-translate-y-1"
          >
            Continue Shopping
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="divide-y divide-gray-100">
                {cart.map((item) => (
                  <div key={item.id} className="p-6">
                    <div className="flex flex-col sm:flex-row">
                      <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-6">
                        <div className="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16" />
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:justify-between">
                          <div>
                            <h2 className="font-bold text-lg text-gray-800">{item.name}</h2>
                            <div className="mt-1 text-sm text-gray-600">
                              <p>Category: {getCategoryName(item.category_id)}</p>
                              <p>Service: {getServiceName(item.category_id)}</p>
                            </div>
                          </div>
                          <div className="mt-2 sm:mt-0">
                            <p className="text-lg font-bold text-indigo-600">₹{Number(item.sale).toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                          <div className="flex items-center">
                            <button
                              onClick={() => decreaseQuantity(item.id)}
                              className="bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg w-8 h-8 flex items-center justify-center"
                            >
                              -
                            </button>
                            <span className="mx-3 text-gray-800 font-medium">{item.quantity}</span>
                            <button
                              onClick={() => increaseQuantity(item)}
                              className="bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg w-8 h-8 flex items-center justify-center"
                            >
                              +
                            </button>
                          </div>
                          <div className="mt-3 sm:mt-0">
                            <p className="text-lg font-bold text-gray-800">Total: ₹{(Number(item.sale) * item.quantity).toFixed(2)}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4">
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                {cart.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.name} × {item.quantity}</span>
                    <span className="font-medium">₹{(Number(item.sale) * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-gray-200 pt-4 mb-6">
                <div className="flex justify-between text-lg font-bold text-gray-800">
                  <span>Total:</span>
                  <span>₹{total.toFixed(2)}</span>
                </div>
              </div>
              
              <button
                className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-lg transition duration-300 mb-4"
              >
                Proceed to Checkout
              </button>
              
              <button
                onClick={handleContinueShopping}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-3 px-4 rounded-lg transition duration-300 mb-3"
              >
                Continue Shopping
              </button>
              
              <button
                onClick={clearCart}
                className="w-full text-red-500 hover:text-red-700 font-medium py-2 px-4 rounded-lg transition duration-300"
              >
                Clear Cart
              </button>

<div className="bg-white rounded-xl shadow-md p-6 mt-6">
  <h2 className="text-xl font-bold text-gray-800 mb-4">Available Pickup Slots</h2>
  {Object.values(pickupSlots).map((day) => (
    <div key={day.date} className="mb-4">
      <h3 className="font-semibold text-gray-700">{day.day} ({day.weekday})</h3>
      <ul className="ml-4 mt-2 space-y-1 text-sm text-gray-600">
        {day.slots.map((slot) => (
          <li key={slot.slot_id}>
            {slot.start_time} – {slot.end_time}
          </li>
        ))}
      </ul>
    </div>
  ))}
</div>

              
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, ShoppingCart, Sparkles, Truck, CreditCard } from 'lucide-react';

// // Simplified cart for demo - replace with your actual cart implementation
// const Cart: React.FC = () => {
//   const navigate = useNavigate();
//   const [cartItems, setCartItems] = useState([
//     {
//       id: 1,
//       name: "Shirt - Cotton",
//       category: "Steam Iron",
//       service: "Dry Cleaning", 
//       price: 45,
//       originalPrice: 60,
//       quantity: 2,
//       image: "👔"
//     },
//     {
//       id: 2,
//       name: "Saree - Silk",
//       category: "Traditional Wear",
//       service: "Saree Rolling",
//       price: 120,
//       originalPrice: 150,
//       quantity: 1,
//       image: "🥻"
//     }
//   ]);
//   const [loading, setLoading] = useState(false);

//   // Calculate totals
//   const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
//   const discount = cartItems.reduce((sum, item) => sum + ((item.originalPrice - item.price) * item.quantity), 0);
//   const deliveryFee = subtotal > 500 ? 0 : 30;
//   const total = subtotal + deliveryFee;

//   const updateQuantity = (id: number, change: number) => {
//     setCartItems(prev => prev.map(item => 
//       item.id === id 
//         ? { ...item, quantity: Math.max(1, item.quantity + change) }
//         : item
//     ));
//   };

//   const removeItem = (id: number) => {
//     setCartItems(prev => prev.filter(item => item.id !== id));
//   };

//   const handleContinueShopping = () => {
//     navigate("/services");
//   };

//   const handleCheckout = () => {
//     setLoading(true);
//     setTimeout(() => {
//       setLoading(false);
//       alert("Proceeding to checkout...");
//     }, 2000);
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
//       {/* Header */}
//       <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
//         <div className="container mx-auto px-4 py-12">
//           <div className="flex items-center justify-between">
//             <div className="flex items-center gap-4">
//               <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
//                 <ShoppingBag className="w-6 h-6" />
//               </div>
//               <div>
//                 <h1 className="text-3xl font-bold">Your Cart</h1>
//                 <p className="text-blue-100">{cartItems.length} items in your cart</p>
//               </div>
//             </div>
//             {cartItems.length > 0 && (
//               <div className="text-right">
//                 <p className="text-blue-100 text-sm">Total Amount</p>
//                 <p className="text-2xl font-bold">₹{total}</p>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>

//       <div className="container mx-auto px-4 py-8">
//         {cartItems.length === 0 ? (
//           // Empty Cart State
//           <div className="text-center py-16">
//             <div className="bg-white rounded-3xl shadow-xl p-12 max-w-md mx-auto transform hover:scale-105 transition-all duration-500">
//               <div className="w-24 h-24 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
//                 <ShoppingCart className="w-12 h-12 text-blue-500" />
//               </div>
//               <h2 className="text-2xl font-bold text-gray-800 mb-4">Your cart is empty</h2>
//               <p className="text-gray-600 mb-8 leading-relaxed">
//                 Looks like you haven't added any items to your cart yet. 
//                 Start shopping to fill it up!
//               </p>
//               <button
//                 onClick={handleContinueShopping}
//                 className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-4 rounded-xl hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105 font-semibold flex items-center gap-3 mx-auto shadow-lg"
//               >
//                 <Sparkles className="w-5 h-5" />
//                 Start Shopping
//               </button>
//             </div>
//           </div>
//         ) : (
//           // Cart with Items
//           <div className="grid lg:grid-cols-3 gap-8">
//             {/* Cart Items */}
//             <div className="lg:col-span-2 space-y-6">
//               <div className="bg-white rounded-3xl shadow-xl p-6">
//                 <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-3">
//                   <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
//                     <ShoppingBag className="w-4 h-4 text-white" />
//                   </div>
//                   Cart Items
//                 </h2>

//                 <div className="space-y-4">
//                   {cartItems.map((item) => (
//                     <div key={item.id} className="group bg-gray-50 rounded-2xl p-6 hover:bg-gray-100 transition-all duration-300">
//                       <div className="flex items-center gap-6">
//                         {/* Item Image/Icon */}
//                         <div className="w-20 h-20 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
//                           {item.image}
//                         </div>

//                         {/* Item Details */}
//                         <div className="flex-1 min-w-0">
//                           <h3 className="font-bold text-lg text-gray-800 mb-1">{item.name}</h3>
//                           <div className="text-sm text-gray-600 space-y-1">
//                             <p>Category: <span className="font-medium">{item.category}</span></p>
//                             <p>Service: <span className="font-medium text-blue-600">{item.service}</span></p>
//                           </div>
                          
//                           <div className="flex items-center gap-4 mt-3">
//                             <div className="flex items-center gap-2">
//                               <span className="text-lg font-bold text-indigo-600">₹{item.price}</span>
//                               {item.originalPrice > item.price && (
//                                 <span className="text-sm text-gray-400 line-through">₹{item.originalPrice}</span>
//                               )}
//                             </div>
//                             {item.originalPrice > item.price && (
//                               <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">
//                                 Save ₹{item.originalPrice - item.price}
//                               </span>
//                             )}
//                           </div>
//                         </div>

//                         {/* Quantity Controls */}
//                         <div className="flex items-center gap-4">
//                           <div className="flex items-center bg-white rounded-xl shadow-md">
//                             <button
//                               onClick={() => updateQuantity(item.id, -1)}
//                               className="p-3 hover:bg-gray-50 rounded-l-xl transition-colors"
//                               disabled={item.quantity <= 1}
//                             >
//                               <Minus className="w-4 h-4 text-gray-600" />
//                             </button>
//                             <span className="px-4 py-3 font-semibold text-gray-800 min-w-[3rem] text-center">
//                               {item.quantity}
//                             </span>
//                             <button
//                               onClick={() => updateQuantity(item.id, 1)}
//                               className="p-3 hover:bg-gray-50 rounded-r-xl transition-colors"
//                             >
//                               <Plus className="w-4 h-4 text-gray-600" />
//                             </button>
//                           </div>

//                           <button
//                             onClick={() => removeItem(item.id)}
//                             className="p-3 text-red-500 hover:bg-red-50 rounded-xl transition-all duration-300 hover:scale-110"
//                           >
//                             <Trash2 className="w-5 h-5" />
//                           </button>
//                         </div>
//                       </div>

//                       {/* Item Total */}
//                       <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between items-center">
//                         <span className="text-gray-600">Item Total:</span>
//                         <span className="text-xl font-bold text-gray-800">₹{item.price * item.quantity}</span>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               </div>

//               {/* Continue Shopping Button */}
//               <button
//                 onClick={handleContinueShopping}
//                 className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 py-4 rounded-2xl transition-all duration-300 font-semibold flex items-center justify-center gap-3"
//               >
//                 <ArrowRight className="w-5 h-5 rotate-180" />
//                 Continue Shopping
//               </button>
//             </div>

//             {/* Order Summary */}
//             <div className="lg:col-span-1">
//               <div className="bg-white rounded-3xl shadow-xl p-8 sticky top-6">
//                 <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-3">
//                   <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
//                     <CreditCard className="w-4 h-4 text-white" />
//                   </div>
//                   Order Summary
//                 </h2>

//                 {/* Order Details */}
//                 <div className="space-y-4 mb-6">
//                   <div className="flex justify-between text-gray-600">
//                     <span>Subtotal ({cartItems.length} items)</span>
//                     <span className="font-medium">₹{subtotal}</span>
//                   </div>
                  
//                   {discount > 0 && (
//                     <div className="flex justify-between text-green-600">
//                       <span>Discount</span>
//                       <span className="font-medium">-₹{discount}</span>
//                     </div>
//                   )}
                  
//                   <div className="flex justify-between text-gray-600">
//                     <span>Delivery Fee</span>
//                     <span className="font-medium">
//                       {deliveryFee === 0 ? (
//                         <span className="text-green-600">FREE</span>
//                       ) : (
//                         `₹${deliveryFee}`
//                       )}
//                     </span>
//                   </div>
                  
//                   {deliveryFee > 0 && (
//                     <div className="text-sm text-blue-600 bg-blue-50 p-3 rounded-xl">
//                       <Truck className="w-4 h-4 inline mr-2" />
//                       Add ₹{500 - subtotal} more for free delivery
//                     </div>
//                   )}
//                 </div>

//                 {/* Total */}
//                 <div className="border-t-2 border-gray-100 pt-4 mb-6">
//                   <div className="flex justify-between items-center">
//                     <span className="text-xl font-bold text-gray-800">Total:</span>
//                     <span className="text-2xl font-bold text-indigo-600">₹{total}</span>
//                   </div>
//                 </div>

//                 {/* Checkout Button */}
//                 <button
//                   onClick={handleCheckout}
//                   disabled={loading}
//                   className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-2xl hover:from-green-600 hover:to-emerald-700 transition-all duration-300 transform hover:scale-[1.02] font-semibold text-lg shadow-lg hover:shadow-xl disabled:opacity-50 flex items-center justify-center gap-3"
//                 >
//                   {loading ? (
//                     <>
//                       <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
//                       Processing...
//                     </>
//                   ) : (
//                     <>
//                       <CreditCard className="w-5 h-5" />
//                       Proceed to Checkout
//                     </>
//                   )}
//                 </button>

//                 {/* Security Badge */}
//                 <div className="mt-6 text-center">
//                   <div className="inline-flex items-center gap-2 text-sm text-gray-500">
//                     <div className="w-4 h-4 text-green-500">🔒</div>
//                     <span>Secure & encrypted payment</span>
//                   </div>
//                 </div>

//                 {/* Benefits */}
//                 <div className="mt-6 space-y-3">
//                   {[
//                     { icon: "🚚", text: "Free pickup & delivery" },
//                     { icon: "⚡", text: "Express service available" },
//                     { icon: "💯", text: "100% satisfaction guarantee" }
//                   ].map((benefit, index) => (
//                     <div key={index} className="flex items-center gap-3 text-sm text-gray-600">
//                       <span className="text-lg">{benefit.icon}</span>
//                       <span>{benefit.text}</span>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Cart;
